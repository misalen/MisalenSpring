package org.misalen.workflow.activiti.config;

import org.activiti.engine.impl.interceptor.Session;
import org.activiti.engine.impl.interceptor.SessionFactory;
import org.activiti.engine.impl.persistence.entity.UserEntityManager;

public class CustomUserEntityManagerFactory implements SessionFactory {

	public Class<?> getSessionType() {
		return UserEntityManager.class;
	}

	public Session openSession() {
		return new CustomUserEntityManager();
	}
}
