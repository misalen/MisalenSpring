package org.misalen.branch;

import org.misalen.common.global.ModuleCode;

public final class DbJpaModuleCode extends ModuleCode {

	@Override
	protected String name() {
		return "misalen-spring-db-jpa";
	}

}
