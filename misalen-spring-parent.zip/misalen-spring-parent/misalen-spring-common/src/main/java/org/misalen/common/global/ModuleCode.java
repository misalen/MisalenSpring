package org.misalen.common.global;

public abstract class ModuleCode {

	protected abstract String name();

	public String getName() {
		return name();
	}

}
