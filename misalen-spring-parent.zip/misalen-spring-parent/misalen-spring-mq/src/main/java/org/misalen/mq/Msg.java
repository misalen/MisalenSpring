package org.misalen.mq;

public class Msg extends Message {
	public String b;

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Msg [b=" + b + "]";
	}
	
}
