package org.misalen.generator.service;

import org.misalen.db.jpa.base.service.CustomService;
import org.misalen.generator.domain.SysFormInfo;
import org.springframework.stereotype.Service;

@Service
public class SysFormInfoService extends CustomService<SysFormInfo, String> {

}
