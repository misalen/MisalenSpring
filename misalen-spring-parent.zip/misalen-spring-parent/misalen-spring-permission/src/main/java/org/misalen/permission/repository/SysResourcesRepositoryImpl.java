package org.misalen.permission.repository;

import org.misalen.db.jpa.base.repository.CustomRepository;
import org.misalen.permission.repository.SysResourcesRepositoryCustom;

public class SysResourcesRepositoryImpl extends CustomRepository implements SysResourcesRepositoryCustom {

}
