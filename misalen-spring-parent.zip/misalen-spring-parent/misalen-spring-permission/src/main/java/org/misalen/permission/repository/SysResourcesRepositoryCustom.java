package org.misalen.permission.repository;

public interface SysResourcesRepositoryCustom {
}
